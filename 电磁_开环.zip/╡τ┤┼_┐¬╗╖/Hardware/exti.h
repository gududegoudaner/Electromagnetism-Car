#ifndef __EXTI_H
#define __EXTI_H


void ELE_EXTI_Init(void);


#endif
