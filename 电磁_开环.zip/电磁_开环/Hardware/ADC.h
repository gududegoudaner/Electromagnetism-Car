#ifndef __ADC_H_
#define __ADC_H_

extern uint16_t AD_Value[4];

void MyAD_Init(void);
uint16_t AD_GetValue(uint8_t ADC_Channel);

#endif
