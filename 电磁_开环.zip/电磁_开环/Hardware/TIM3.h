#ifndef __TIM3_H_
#define __TIM3_H_

void TIM3_Init(void);

#endif
