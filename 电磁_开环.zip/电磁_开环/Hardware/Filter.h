#ifndef __FILTER_H
#define __FILTER_H

uint16_t SlideFilter(uint16_t AD_Val,int ch);

#endif
