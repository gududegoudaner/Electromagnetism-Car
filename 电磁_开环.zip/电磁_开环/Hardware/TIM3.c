#include "sys.h"

void TIM3_Init(void)//20ms 50hz
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);//����TIM3��ʱ��
	
	TIM_InternalClockConfig(TIM3);//����ʱ��Դ
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;

	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up; //���ϼ���ģʽ 
	TIM_TimeBaseInitStruct.TIM_Period=50;   //�Զ�װ��ֵ
	TIM_TimeBaseInitStruct.TIM_Prescaler=7200;   //Ԥ��Ƶϵ��
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStruct); 	

	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
	
	TIM_Cmd(TIM3, ENABLE);	
}
